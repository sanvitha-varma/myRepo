package com.app.gloesports.repository;

// make this into a equipment repository
public interface EquipmentRepository  {

}
