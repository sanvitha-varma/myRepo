package com.app.gloesports.repository;

// make this into a user repository
public interface UserRepository {
}
