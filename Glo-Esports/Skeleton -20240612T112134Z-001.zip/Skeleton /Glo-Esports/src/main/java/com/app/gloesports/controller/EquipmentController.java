package com.app.gloesports.controller;

// It is a controller class that handles the equipment related requests
public class EquipmentController {

    // Add equipment to a user

    // Get equipment by equipmentId

    // Delete equipment from a User by equipmentId
}
