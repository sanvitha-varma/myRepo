package com.app.gloesports.controller;

// It is a controller class that handles the user related requests
public class UserController {

    // Add a user

    //Get a user by userId

}
