package com.app.gloesports.service.impl;

import com.app.gloesports.dto.EquipmentDto;
import com.app.gloesports.service.EquipmentService;

// make this into a service layer for Equipment entity

public class EquipmentServiceImpl implements EquipmentService {

    @Override
    public EquipmentDto addEquipmentToUser(EquipmentDto equipmentDto, Long userId) {
        return null;
    }

    @Override
    public EquipmentDto getEquipmentById(Long userId, Long equipmentId) {
        return null;
    }

    @Override
    public EquipmentDto deleteEquipmentById(Long equipmentId, Long userId) {
        return null;
    }
}
