package com.app.gloesports.service.impl;

import com.app.gloesports.dto.UserDto;
import com.app.gloesports.service.UserService;

// make this into a service layer for User entity
public class UserServiceImpl implements UserService {

    @Override
    public UserDto addUser(UserDto userDTO) {
        return null;
    }

    @Override
    public UserDto getUserById(Long userId) {
        return null;
    }
}
