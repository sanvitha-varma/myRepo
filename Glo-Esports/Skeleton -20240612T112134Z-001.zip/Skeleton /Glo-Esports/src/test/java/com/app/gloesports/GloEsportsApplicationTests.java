package com.app.gloesports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GloEsportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
